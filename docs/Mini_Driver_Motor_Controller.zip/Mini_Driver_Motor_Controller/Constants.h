
#define maxvolt   685                                      // 100% battery voltage
#define maxspeed 1900                                      // encoder pulses per second for speed=100% with battery at 100%
